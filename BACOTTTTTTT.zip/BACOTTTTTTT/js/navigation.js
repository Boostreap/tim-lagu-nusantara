document.addEventListener('DOMContentLoaded', function() {
    const prevButton = document.querySelector('.arrow.prev');
    const nextButton = document.querySelector('.arrow.next');

    if (prevButton) {
        prevButton.addEventListener('click', function() {
            // Arahkan ke halaman sebelumnya
            window.history.back();
        });
    }

    if (nextButton) {
        nextButton.addEventListener('click', function() {
            // Arahkan ke halaman berikutnya
            window.history.forward();
        });
    }
});